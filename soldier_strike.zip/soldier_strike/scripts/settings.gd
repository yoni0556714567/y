extends Node
## הגדרות גלובליות, שיאים וניגון צלילים (Autoload בשם Settings)

const SAVE_PATH := "user://settings.cfg"
const SOUND_NAMES := ["shoot", "shotgun", "sniper", "explosion", "hurt", "reload", "pickup", "empty", "enemy_shot", "hit"]

var sensitivity: float = 1.0
var difficulty: int = 1
var aim_assist: bool = true
var auto_fire: bool = false
var invert_y: bool = false
var fov: float = 75.0
var volume: float = 0.8
var shadows: bool = true
var high_score: int = 0
var best_wave: int = 0

var _sounds: Dictionary = {}
var _players: Array = []
var _next: int = 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	load_data()
	for n in SOUND_NAMES:
		var path: String = "res://sounds/%s.wav" % n
		if ResourceLoader.exists(path):
			_sounds[n] = load(path)
	for i in 8:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players.append(p)


func play(sound_name: String, volume_db: float = 0.0, pitch: float = 1.0) -> void:
	if not _sounds.has(sound_name) or volume <= 0.0:
		return
	var p: AudioStreamPlayer = _players[_next]
	_next = (_next + 1) % _players.size()
	p.stream = _sounds[sound_name]
	p.volume_db = volume_db + linear_to_db(volume)
	p.pitch_scale = pitch
	p.play()


func save_data() -> void:
	var c := ConfigFile.new()
	c.set_value("settings", "sensitivity", sensitivity)
	c.set_value("settings", "difficulty", difficulty)
	c.set_value("settings", "aim_assist", aim_assist)
	c.set_value("settings", "auto_fire", auto_fire)
	c.set_value("settings", "invert_y", invert_y)
	c.set_value("settings", "fov", fov)
	c.set_value("settings", "volume", volume)
	c.set_value("settings", "shadows", shadows)
	c.set_value("progress", "high_score", high_score)
	c.set_value("progress", "best_wave", best_wave)
	c.save(SAVE_PATH)


func load_data() -> void:
	var c := ConfigFile.new()
	if c.load(SAVE_PATH) != OK:
		return
	sensitivity = c.get_value("settings", "sensitivity", sensitivity)
	difficulty = c.get_value("settings", "difficulty", difficulty)
	aim_assist = c.get_value("settings", "aim_assist", aim_assist)
	auto_fire = c.get_value("settings", "auto_fire", auto_fire)
	invert_y = c.get_value("settings", "invert_y", invert_y)
	fov = c.get_value("settings", "fov", fov)
	volume = c.get_value("settings", "volume", volume)
	shadows = c.get_value("settings", "shadows", shadows)
	high_score = c.get_value("progress", "high_score", high_score)
	best_wave = c.get_value("progress", "best_wave", best_wave)
