extends Node3D
## הסצנה הראשית: זירה, גלי אויבים, רימונים, פריטים, הפסקה וסיום משחק

const PlayerScript := preload("res://scripts/player.gd")
const EnemyScript := preload("res://scripts/enemy.gd")
const PickupScript := preload("res://scripts/pickup.gd")
const ControlsScript := preload("res://scripts/touch_controls.gd")
const HudScript := preload("res://scripts/hud.gd")

const HALF := 36.0
const HP_MULT := [0.7, 1.0, 1.4]
const DMG_MULT := [0.6, 1.0, 1.5]

var player
var controls
var hud

var wave: int = 0
var score: int = 0
var to_spawn: int = 0
var spawn_cd: float = 0.0
var between: float = 3.0
var wave_active: bool = false
var over: bool = false
var obstacles: Array = []


func _ready() -> void:
	randomize()
	if not DisplayServer.is_touchscreen_available():
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	_build_environment()
	_build_arena()
	_build_ui()
	_spawn_player()
	hud.resume_pressed.connect(_set_paused.bind(false))
	hud.restart_pressed.connect(_restart)
	hud.menu_pressed.connect(_to_menu)
	hud.show_banner("התכונן!", 2.5)


# ---------------------------------------------------------------- בנייה

func _build_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.25, 0.45, 0.75)
	sm.sky_horizon_color = Color(0.7, 0.8, 0.9)
	sm.ground_horizon_color = Color(0.7, 0.8, 0.9)
	sm.ground_bottom_color = Color(0.35, 0.4, 0.35)
	sky.sky_material = sm
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.fog_enabled = true
	env.fog_light_color = Color(0.7, 0.78, 0.85)
	env.fog_density = 0.012
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50.0, 30.0, 0.0)
	sun.shadow_enabled = Settings.shadows
	sun.directional_shadow_max_distance = 60.0
	add_child(sun)


func _add_box(pos: Vector3, size: Vector3, color: Color) -> void:
	var b := StaticBody3D.new()
	b.collision_layer = 1
	b.collision_mask = 0
	b.position = pos
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = size
	cs.shape = sh
	b.add_child(cs)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mi.material_override = mat
	b.add_child(mi)
	add_child(b)


func _build_arena() -> void:
	var span: float = HALF * 2.0 + 4.0
	_add_box(Vector3(0, -0.5, 0), Vector3(span, 1.0, span), Color(0.36, 0.43, 0.3))
	var wall_col: Color = Color(0.5, 0.5, 0.52)
	_add_box(Vector3(0, 2.5, -HALF - 1.0), Vector3(span, 5.0, 2.0), wall_col)
	_add_box(Vector3(0, 2.5, HALF + 1.0), Vector3(span, 5.0, 2.0), wall_col)
	_add_box(Vector3(-HALF - 1.0, 2.5, 0), Vector3(2.0, 5.0, span), wall_col)
	_add_box(Vector3(HALF + 1.0, 2.5, 0), Vector3(2.0, 5.0, span), wall_col)

	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	var made: int = 0
	var tries: int = 0
	while made < 26 and tries < 200:
		tries += 1
		var x: float = rng.randf_range(-HALF + 4.0, HALF - 4.0)
		var z: float = rng.randf_range(-HALF + 4.0, HALF - 4.0)
		if Vector2(x, z).length() < 7.0:
			continue
		var w: float = rng.randf_range(1.5, 4.5)
		var d: float = rng.randf_range(1.5, 4.5)
		var h: float = rng.randf_range(1.0, 3.5)
		var tint: float = rng.randf_range(-0.08, 0.08)
		_add_box(Vector3(x, h * 0.5, z), Vector3(w, h, d), Color(0.5 + tint, 0.4 + tint, 0.27))
		obstacles.append(Rect2(x - w * 0.5, z - d * 0.5, w, d))
		made += 1


func _build_ui() -> void:
	var cl := CanvasLayer.new()
	cl.layer = 5
	add_child(cl)
	controls = ControlsScript.new()
	cl.add_child(controls)
	controls.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var hl := CanvasLayer.new()
	hl.layer = 6
	hl.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(hl)
	hud = HudScript.new()
	hl.add_child(hud)
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _spawn_player() -> void:
	player = PlayerScript.new()
	player.controls = controls
	player.game = self
	player.position = Vector3(0, 0.1, 0)
	add_child(player)
	player.died.connect(_on_player_died)
	player.damaged.connect(func(_a) -> void: hud.flash_damage())
	player.hit_marker.connect(func(h, k) -> void: hud.show_hit(h, k))


# ---------------------------------------------------------------- לולאת משחק

func _process(delta: float) -> void:
	if over:
		return
	if controls.take("pause"):
		_set_paused(true)
		return
	_wave_logic(delta)
	var count: int = get_tree().get_nodes_in_group("enemies").size()
	hud.update_stats(player, wave, score, count + to_spawn)


func _wave_logic(delta: float) -> void:
	var count: int = get_tree().get_nodes_in_group("enemies").size()
	if wave_active:
		if to_spawn > 0:
			spawn_cd -= delta
			if spawn_cd <= 0.0 and count < mini(5 + wave, 14):
				_spawn_enemy()
				to_spawn -= 1
				spawn_cd = maxf(0.4, 1.6 - wave * 0.08)
		elif count == 0:
			wave_active = false
			between = 5.0
			score += wave * 100
			Settings.best_wave = maxi(Settings.best_wave, wave)
			player.pick_up("health")
			player.pick_up("ammo")
			player.pick_up("grenade")
			hud.show_banner("גל %d הושלם!" % wave, 3.0)
	else:
		between -= delta
		if between <= 0.0:
			_start_wave()


func _start_wave() -> void:
	wave += 1
	to_spawn = mini(5 + wave * 3, 40)
	spawn_cd = 0.5
	wave_active = true
	hud.show_banner("גל %d" % wave, 2.5)


func _spawn_enemy() -> void:
	var pos: Vector3 = Vector3(0, 0.1, -HALF + 4.0)
	for i in 14:
		var cand: Vector3 = Vector3(randf_range(-HALF + 3.0, HALF - 3.0), 0.1, randf_range(-HALF + 3.0, HALF - 3.0))
		if cand.distance_to(player.global_position) < 18.0:
			continue
		var blocked: bool = false
		for r in obstacles:
			if r.grow(1.2).has_point(Vector2(cand.x, cand.z)):
				blocked = true
				break
		if blocked:
			continue
		pos = cand
		break

	var roll: float = randf()
	var kind: int = 0
	if wave >= 3 and roll < minf(0.08 + wave * 0.02, 0.25):
		kind = 2
	elif wave >= 2 and roll < 0.45:
		kind = 1

	var e = EnemyScript.new()
	e.kind = kind
	e.player = player
	e.game = self
	e.hp_mult = HP_MULT[Settings.difficulty] * (1.0 + 0.06 * wave)
	e.dmg_mult = DMG_MULT[Settings.difficulty]
	e.position = pos
	add_child(e)
	e.killed.connect(_on_enemy_killed)


func _on_enemy_killed(e, head: bool) -> void:
	score += 100 + (50 if head else 0)
	if e.kind == 2 or randf() < 0.3:
		_drop(e.global_position)


func _drop(pos: Vector3) -> void:
	var roll: float = randf()
	var kind: String = "ammo"
	if roll < 0.3:
		kind = "health"
	elif roll < 0.45:
		kind = "armor"
	elif roll < 0.6:
		kind = "grenade"
	var p = PickupScript.new()
	p.kind = kind
	p.position = Vector3(pos.x, 0.1, pos.z)
	add_child(p)


# ---------------------------------------------------------------- אפקטים ורימונים

func spawn_tracer(from: Vector3, to: Vector3, color: Color) -> void:
	var seg_len: float = from.distance_to(to)
	if seg_len < 0.2:
		return
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.03, 0.03, seg_len)
	mi.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = color
	mi.material_override = mat
	mi.position = (from + to) * 0.5
	add_child(mi)
	var up: Vector3 = Vector3.UP
	if absf((to - from).normalized().y) > 0.98:
		up = Vector3.RIGHT
	mi.look_at(to, up)
	get_tree().create_timer(0.06, false).timeout.connect(mi.queue_free)


func spawn_impact(pos: Vector3, color: Color) -> void:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.09
	sm.height = 0.18
	sm.radial_segments = 8
	sm.rings = 4
	mi.mesh = sm
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = color
	mi.material_override = mat
	mi.position = pos
	add_child(mi)
	get_tree().create_timer(0.18, false).timeout.connect(mi.queue_free)


func throw_grenade(pos: Vector3, vel: Vector3) -> void:
	var g := RigidBody3D.new()
	g.collision_layer = 0
	g.collision_mask = 1
	g.position = pos
	var cs := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = 0.12
	cs.shape = sh
	g.add_child(cs)
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.12
	sm.height = 0.24
	mi.mesh = sm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.2, 0.3, 0.15)
	mi.material_override = mat
	g.add_child(mi)
	var pm := PhysicsMaterial.new()
	pm.bounce = 0.35
	pm.friction = 0.8
	g.physics_material_override = pm
	add_child(g)
	g.linear_velocity = vel
	Settings.play("reload", -6.0, 1.7)
	get_tree().create_timer(2.0, false).timeout.connect(_explode.bind(g))


func _explode(g) -> void:
	if not is_instance_valid(g):
		return
	var pos: Vector3 = g.global_position
	g.queue_free()
	Settings.play("explosion", 0.0, randf_range(0.9, 1.1))

	for e in get_tree().get_nodes_in_group("enemies"):
		var d: float = e.global_position.distance_to(pos)
		if d < 7.0:
			e.take_damage(170.0 * (1.0 - d / 7.0) + 20.0, false)
	var pd: float = player.global_position.distance_to(pos)
	if pd < 5.0 and player.alive:
		player.take_damage(50.0 * (1.0 - pd / 5.0))
	if pd < 20.0:
		player.shake = maxf(player.shake, 0.5)

	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 1.0
	sm.height = 2.0
	sm.radial_segments = 16
	sm.rings = 8
	mi.mesh = sm
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = Color(1.0, 0.55, 0.1, 0.85)
	mi.material_override = mat
	mi.position = pos
	mi.scale = Vector3.ONE * 0.3
	add_child(mi)
	var tw := mi.create_tween()
	tw.set_parallel(true)
	tw.tween_property(mi, "scale", Vector3.ONE * 7.0, 0.35)
	tw.tween_property(mat, "albedo_color:a", 0.0, 0.35)
	tw.chain().tween_callback(mi.queue_free)


# ---------------------------------------------------------------- מצבי משחק

func _on_player_died() -> void:
	over = true
	if score > Settings.high_score:
		Settings.high_score = score
	Settings.best_wave = maxi(Settings.best_wave, wave)
	Settings.save_data()
	controls.set_process_input(false)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	hud.show_game_over(score, wave, Settings.high_score)


func _set_paused(on: bool) -> void:
	if over:
		return
	get_tree().paused = on
	hud.show_pause(on)
	if not DisplayServer.is_touchscreen_available():
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if on else Input.MOUSE_MODE_CAPTURED


func _restart() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()


func _to_menu() -> void:
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().change_scene_to_file("res://scenes/menu.tscn")


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_set_paused(not get_tree().paused)
	elif what == NOTIFICATION_APPLICATION_PAUSED:
		_set_paused(true)
