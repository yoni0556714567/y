extends CharacterBody3D
## אויב. kind: 0 = חייל רגיל (יורה), 1 = רץ (תקיפה מגע), 2 = כבד (שריון ואש מהירה)

signal killed(enemy, headshot)

var kind: int = 0
var player
var game
var hp_mult: float = 1.0
var dmg_mult: float = 1.0

var hp: float = 60.0
var speed: float = 3.0
var damage: float = 6.0
var fire_rate: float = 1.0
var pref_dist: float = 14.0
var accuracy: float = 0.55
var s: float = 1.0
var head_y: float = 1.45
var dead: bool = false
var shoot_cd: float = 1.0
var attack_cd: float = 0.0
var strafe_t: float = 0.0
var strafe_dir: float = 1.0
var check_t: float = 0.6
var last_pos: Vector3 = Vector3.ZERO
var flash_t: float = 0.0
var mats: Array = []


func _ready() -> void:
	add_to_group("enemies")
	collision_layer = 4
	collision_mask = 1

	var body_color: Color = Color(0.55, 0.18, 0.18)
	match kind:
		0:
			hp = 60.0
			speed = 3.2
			damage = 7.0
			fire_rate = 1.1
			pref_dist = 14.0
			accuracy = 0.55
			s = 1.0
			body_color = Color(0.55, 0.18, 0.18)
		1:
			hp = 40.0
			speed = 6.5
			damage = 14.0
			fire_rate = 0.0
			pref_dist = 0.0
			accuracy = 0.0
			s = 0.95
			body_color = Color(0.85, 0.45, 0.1)
		_:
			hp = 240.0
			speed = 2.2
			damage = 9.0
			fire_rate = 0.45
			pref_dist = 18.0
			accuracy = 0.5
			s = 1.3
			body_color = Color(0.25, 0.25, 0.38)
	hp *= hp_mult
	damage *= dmg_mult
	head_y = 1.45 * s
	shoot_cd = randf_range(0.6, 1.8)
	strafe_dir = 1.0 if randf() < 0.5 else -1.0

	# גוף
	_part(Vector3(0.5, 0.7, 0.3) * s, Vector3(0.0, 0.35, 0.0) * s, Color(0.18, 0.18, 0.2))
	_part(Vector3(0.7, 0.8, 0.4) * s, Vector3(0.0, 1.1, 0.0) * s, body_color)
	_part(Vector3(0.18, 0.6, 0.18) * s, Vector3(-0.45, 1.1, 0.0) * s, body_color)
	_part(Vector3(0.18, 0.6, 0.18) * s, Vector3(0.45, 1.1, 0.0) * s, body_color)
	_part(Vector3(0.45, 0.45, 0.45) * s, Vector3(0.0, 1.65, 0.0) * s, Color(0.85, 0.65, 0.5), true)
	_part(Vector3(0.52, 0.16, 0.52) * s, Vector3(0.0, 1.82, 0.0) * s, Color(0.15, 0.15, 0.18))
	_part(Vector3(0.1, 0.12, 0.7) * s, Vector3(0.3, 1.2, -0.35) * s, Color(0.1, 0.1, 0.1))
	if kind == 2:
		_part(Vector3(0.8, 0.5, 0.5) * s, Vector3(0.0, 1.15, 0.0) * s, Color(0.4, 0.4, 0.45))

	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4 * s
	cap.height = 1.9 * s
	cs.shape = cap
	cs.position.y = 0.95 * s
	add_child(cs)
	last_pos = global_position


func _part(size: Vector3, pos: Vector3, color: Color, sphere: bool = false) -> void:
	var mi := MeshInstance3D.new()
	if sphere:
		var sm := SphereMesh.new()
		sm.radius = size.x * 0.5
		sm.height = size.x
		sm.radial_segments = 12
		sm.rings = 6
		mi.mesh = sm
	else:
		var bm := BoxMesh.new()
		bm.size = size
		mi.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mi.material_override = mat
	mi.position = pos
	mats.append(mat)
	add_child(mi)


func _physics_process(delta: float) -> void:
	if flash_t > 0.0:
		flash_t -= delta
		if flash_t <= 0.0:
			for m in mats:
				m.emission_enabled = false
	if dead or player == null or not player.alive:
		return

	var to_p: Vector3 = player.global_position - global_position
	to_p.y = 0.0
	var dist: float = to_p.length()
	var dir: Vector3 = Vector3.ZERO
	if dist > 0.01:
		dir = to_p / dist
	rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), minf(1.0, 8.0 * delta))

	var side: Vector3 = Vector3(-dir.z, 0.0, dir.x) * strafe_dir
	var mv: Vector3 = Vector3.ZERO
	if strafe_t > 0.0:
		strafe_t -= delta
		mv = side * 0.9 + dir * 0.2
	elif kind == 1:
		if dist > 1.5:
			mv = dir
	else:
		if dist > pref_dist + 2.0:
			mv = dir
		elif dist < pref_dist - 4.0:
			mv = -dir * 0.7
		else:
			mv = side * 0.5
	velocity.x = mv.x * speed
	velocity.z = mv.z * speed
	if is_on_floor():
		velocity.y = -0.5
	else:
		velocity.y -= 20.0 * delta
	move_and_slide()

	# זיהוי תקיעות מאחורי מכשול
	check_t -= delta
	if check_t <= 0.0:
		check_t = 0.6
		var moved: float = global_position.distance_to(last_pos)
		last_pos = global_position
		if mv.length() > 0.6 and moved < speed * 0.12 and strafe_t <= 0.0:
			strafe_t = 1.3
			strafe_dir = 1.0 if randf() < 0.5 else -1.0

	if kind != 1:
		shoot_cd -= delta
		if shoot_cd <= 0.0 and dist < 38.0 and _has_los():
			shoot_cd = fire_rate * randf_range(0.8, 1.4)
			_fire(dist)
	else:
		attack_cd -= delta
		if dist < 1.9 and attack_cd <= 0.0 and absf(player.global_position.y - global_position.y) < 2.0:
			attack_cd = 0.8
			player.take_damage(damage)


func _has_los() -> bool:
	var from: Vector3 = global_position + Vector3(0.0, head_y * 0.9, 0.0)
	var to: Vector3 = player.global_position + Vector3(0.0, 1.2, 0.0)
	var q := PhysicsRayQueryParameters3D.create(from, to, 1)
	return get_world_3d().direct_space_state.intersect_ray(q).is_empty()


func _fire(dist: float) -> void:
	var fwd: Vector3 = -global_transform.basis.z
	var from: Vector3 = global_position + Vector3(0.0, 1.2 * s, 0.0) + fwd * 0.6 * s
	var target: Vector3 = player.global_position + Vector3(0.0, 1.2, 0.0)
	var chance: float = clampf(accuracy - dist * 0.012, 0.12, 0.85)
	var hit: bool = randf() < chance
	if not hit:
		target += Vector3(randf_range(-1.5, 1.5), randf_range(-0.8, 0.8), randf_range(-1.5, 1.5))
	game.spawn_tracer(from, target, Color(1.0, 0.35, 0.2))
	Settings.play("enemy_shot", clampf(-4.0 - dist * 0.35, -30.0, -4.0), randf_range(0.85, 1.1))
	if hit:
		player.take_damage(damage)


## מחזיר true אם האויב מת מהפגיעה
func take_damage(amount: float, head: bool = false) -> bool:
	if dead:
		return false
	if head:
		amount *= 2.0
	hp -= amount
	flash_t = 0.08
	for m in mats:
		m.emission_enabled = true
		m.emission = Color(1, 1, 1)
	if hp <= 0.0:
		_die(head)
		return true
	return false


func _die(head: bool) -> void:
	dead = true
	remove_from_group("enemies")
	collision_layer = 0
	killed.emit(self, head)
	var tw := create_tween()
	tw.tween_property(self, "rotation:x", -PI / 2.0, 0.45)
	tw.tween_interval(1.2)
	tw.tween_callback(queue_free)
