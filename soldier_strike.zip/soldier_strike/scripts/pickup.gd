extends Area3D
## פריט לאיסוף: health / armor / ammo / grenade

var kind: String = "ammo"
var life: float = 30.0
var mesh: MeshInstance3D
var t: float = 0.0


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	monitoring = true

	var cs := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = 1.1
	cs.shape = sh
	cs.position.y = 0.6
	add_child(cs)

	var color: Color = Color(0.95, 0.8, 0.2)
	match kind:
		"health":
			color = Color(0.2, 0.9, 0.3)
		"armor":
			color = Color(0.3, 0.5, 1.0)
		"grenade":
			color = Color(0.85, 0.2, 0.2)

	mesh = MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.5, 0.5, 0.5)
	mesh.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.emission_enabled = true
	mat.emission = color
	mat.emission_energy_multiplier = 0.8
	mesh.material_override = mat
	mesh.position.y = 0.6
	add_child(mesh)
	body_entered.connect(_on_body)


func _process(delta: float) -> void:
	t += delta
	rotate_y(delta * 2.0)
	mesh.position.y = 0.6 + sin(t * 3.0) * 0.12
	life -= delta
	if life <= 0.0:
		queue_free()


func _on_body(body: Node) -> void:
	if body.has_method("pick_up") and body.pick_up(kind):
		Settings.play("pickup", -4.0)
		queue_free()
