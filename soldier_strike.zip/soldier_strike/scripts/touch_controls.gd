extends Control
## בקרת מגע: ג'ויסטיק דינמי משמאל, מבט בהחלקה מימין, כפתורים.
## תומך גם במקלדת ועכבר לצורך בדיקה במחשב.

const JOY_RADIUS := 110.0

var move: Vector2 = Vector2.ZERO
var look: Vector2 = Vector2.ZERO

var _touches: Dictionary = {}
var _joy_index: int = -1
var _joy_origin: Vector2 = Vector2.ZERO
var _joy_pos: Vector2 = Vector2.ZERO
var _pressed: Dictionary = {}
var _buttons: Dictionary = {}


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(_layout)
	get_viewport().size_changed.connect(_layout)
	_layout()


func _layout() -> void:
	var s: Vector2 = get_viewport_rect().size
	_buttons = {
		"fire": {"center": Vector2(s.x - 170, s.y - 160), "radius": 90.0, "label": "אש"},
		"jump": {"center": Vector2(s.x - 80, s.y - 330), "radius": 52.0, "label": "קפוץ"},
		"reload": {"center": Vector2(s.x - 340, s.y - 120), "radius": 52.0, "label": "טען"},
		"grenade": {"center": Vector2(s.x - 310, s.y - 260), "radius": 52.0, "label": "רימון"},
		"switch": {"center": Vector2(s.x - 200, s.y - 345), "radius": 52.0, "label": "נשק"},
		"pause": {"center": Vector2(s.x - 60, 60), "radius": 36.0, "label": "II"},
	}
	queue_redraw()


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			_touch_down(event.index, event.position)
		else:
			_touch_up(event.index)
	elif event is InputEventScreenDrag:
		_touch_drag(event.index, event.position, event.relative)
	elif event is InputEventMouseMotion:
		if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
			look += event.relative
	elif event is InputEventKey:
		if event.pressed and not event.echo:
			match event.keycode:
				KEY_SPACE:
					_pressed["jump"] = true
				KEY_R:
					_pressed["reload"] = true
				KEY_G:
					_pressed["grenade"] = true
				KEY_Q, KEY_E:
					_pressed["switch"] = true
				KEY_ESCAPE:
					_pressed["pause"] = true


func _touch_down(index: int, pos: Vector2) -> void:
	for n in _buttons:
		var b: Dictionary = _buttons[n]
		if pos.distance_to(b["center"]) <= float(b["radius"]) * 1.15:
			_touches[index] = n
			if n != "fire":
				_pressed[n] = true
			return
	var s: Vector2 = get_viewport_rect().size
	if pos.x < s.x * 0.42 and _joy_index == -1:
		_joy_index = index
		_joy_origin = pos
		_joy_pos = pos
		move = Vector2.ZERO
		_touches[index] = "joy"
	else:
		_touches[index] = "look"


func _touch_up(index: int) -> void:
	if not _touches.has(index):
		return
	if _touches[index] == "joy":
		_joy_index = -1
		move = Vector2.ZERO
	_touches.erase(index)


func _touch_drag(index: int, pos: Vector2, rel: Vector2) -> void:
	if not _touches.has(index):
		return
	var role: String = _touches[index]
	if role == "joy":
		_joy_pos = pos
		move = ((pos - _joy_origin) / JOY_RADIUS).limit_length(1.0)
	elif role == "look":
		look += rel
	elif role == "fire":
		look += rel * 0.7


## כפתור שנלחץ - מחזיר true פעם אחת בלבד
func take(button_name: String) -> bool:
	if _pressed.get(button_name, false):
		_pressed[button_name] = false
		return true
	return false


func consume_look() -> Vector2:
	var l: Vector2 = look
	look = Vector2.ZERO
	return l


func get_move() -> Vector2:
	if _joy_index != -1:
		return move
	var v := Vector2.ZERO
	if Input.is_key_pressed(KEY_W):
		v.y -= 1.0
	if Input.is_key_pressed(KEY_S):
		v.y += 1.0
	if Input.is_key_pressed(KEY_A):
		v.x -= 1.0
	if Input.is_key_pressed(KEY_D):
		v.x += 1.0
	return v.limit_length(1.0)


func is_firing() -> bool:
	if _touches.values().has("fire"):
		return true
	return Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)


func _process(_delta: float) -> void:
	queue_redraw()


func _draw() -> void:
	var font: Font = ThemeDB.fallback_font
	var active_roles: Array = _touches.values()
	for n in _buttons:
		var b: Dictionary = _buttons[n]
		var c: Vector2 = b["center"]
		var r: float = b["radius"]
		var on: bool = active_roles.has(n)
		draw_circle(c, r, Color(1, 1, 1, 0.34 if on else 0.16))
		draw_arc(c, r, 0.0, TAU, 40, Color(1, 1, 1, 0.55), 3.0)
		var lbl: String = b["label"]
		var sz: Vector2 = font.get_string_size(lbl, HORIZONTAL_ALIGNMENT_LEFT, -1, 24)
		draw_string(font, c + Vector2(-sz.x * 0.5, 8.0), lbl, HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color(1, 1, 1, 0.95))
	if _joy_index != -1:
		draw_circle(_joy_origin, JOY_RADIUS, Color(1, 1, 1, 0.12))
		draw_arc(_joy_origin, JOY_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.5), 3.0)
		var knob: Vector2 = _joy_origin + (_joy_pos - _joy_origin).limit_length(JOY_RADIUS)
		draw_circle(knob, 46.0, Color(1, 1, 1, 0.4))
	else:
		var s: Vector2 = get_viewport_rect().size
		draw_arc(Vector2(170, s.y - 170), JOY_RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.25), 3.0)
