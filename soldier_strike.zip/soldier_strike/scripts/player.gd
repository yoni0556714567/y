extends CharacterBody3D
## שחקן: תנועה, מבט, ארבעה סוגי נשק, טעינה, רימונים ושברי חיים/שריון

signal died
signal damaged(amount)
signal hit_marker(headshot, killed)

const SPEED := 6.5
const JUMP_VELOCITY := 6.2
const GRAVITY := 18.0
const EYE_HEIGHT := 1.6

var controls
var game

var hp: float = 100.0
var max_hp: float = 100.0
var armor: float = 0.0
var max_armor: float = 100.0
var grenades: int = 3
var alive: bool = true

var current: int = 0
var reloading: bool = false
var reload_left: float = 0.0
var cooldown: float = 0.0
var was_firing: bool = false

var pitch: float = 0.0
var shake: float = 0.0
var recoil: float = 0.0

var head: Node3D
var camera: Camera3D
var gun: MeshInstance3D
var gun_rest: Vector3 = Vector3.ZERO

var weapons: Array = [
	{"name": "אקדח", "damage": 30.0, "rate": 0.25, "mag": 12, "reserve": 84, "pellets": 1, "spread": 0.006,
		"auto": false, "reload": 1.0, "sound": "shoot", "color": Color(0.25, 0.25, 0.3), "dims": Vector3(0.07, 0.12, 0.3), "kick": 0.01},
	{"name": "רובה סער", "damage": 20.0, "rate": 0.09, "mag": 30, "reserve": 180, "pellets": 1, "spread": 0.02,
		"auto": true, "reload": 1.6, "sound": "shoot", "color": Color(0.2, 0.22, 0.2), "dims": Vector3(0.08, 0.12, 0.6), "kick": 0.012},
	{"name": "שוטגן", "damage": 14.0, "rate": 0.85, "mag": 6, "reserve": 42, "pellets": 8, "spread": 0.07,
		"auto": false, "reload": 2.2, "sound": "shotgun", "color": Color(0.35, 0.25, 0.15), "dims": Vector3(0.1, 0.12, 0.7), "kick": 0.05},
	{"name": "צלף", "damage": 130.0, "rate": 1.1, "mag": 5, "reserve": 25, "pellets": 1, "spread": 0.001,
		"auto": false, "reload": 2.4, "sound": "sniper", "color": Color(0.15, 0.2, 0.15), "dims": Vector3(0.07, 0.1, 0.95), "kick": 0.07},
]
var mags: Array = []
var reserves: Array = []


func _ready() -> void:
	collision_layer = 2
	collision_mask = 1

	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.4
	cap.height = 1.8
	cs.shape = cap
	cs.position.y = 0.9
	add_child(cs)

	head = Node3D.new()
	head.position = Vector3(0, EYE_HEIGHT, 0)
	add_child(head)

	camera = Camera3D.new()
	camera.fov = Settings.fov
	camera.near = 0.05
	camera.far = 150.0
	head.add_child(camera)
	camera.current = true

	gun = MeshInstance3D.new()
	camera.add_child(gun)

	for w in weapons:
		mags.append(w["mag"])
		reserves.append(w["reserve"])
	_apply_weapon_visual()


func _apply_weapon_visual() -> void:
	var w: Dictionary = weapons[current]
	var mesh := BoxMesh.new()
	mesh.size = w["dims"]
	gun.mesh = mesh
	var m := StandardMaterial3D.new()
	m.albedo_color = w["color"]
	gun.material_override = m
	var d: Vector3 = w["dims"]
	gun_rest = Vector3(0.26, -0.22, -0.4 - d.z * 0.5)
	gun.position = gun_rest


func _physics_process(delta: float) -> void:
	if not alive:
		return

	# מבט
	var l: Vector2 = controls.consume_look()
	var sens: float = 0.0035 * Settings.sensitivity
	rotate_y(-l.x * sens)
	var ydir: float = -1.0 if Settings.invert_y else 1.0
	pitch = clampf(pitch - l.y * sens * ydir, -1.45, 1.45)
	head.rotation.x = pitch

	# תנועה
	var mv: Vector2 = controls.get_move()
	var dir: Vector3 = transform.basis * Vector3(mv.x, 0.0, mv.y)
	velocity.x = move_toward(velocity.x, dir.x * SPEED, 45.0 * delta)
	velocity.z = move_toward(velocity.z, dir.z * SPEED, 45.0 * delta)
	if is_on_floor():
		velocity.y = -0.5
		if controls.take("jump"):
			velocity.y = JUMP_VELOCITY
	else:
		velocity.y -= GRAVITY * delta
	move_and_slide()

	# החלפת נשק, טעינה, רימון
	if controls.take("switch"):
		current = (current + 1) % weapons.size()
		reloading = false
		cooldown = 0.25
		_apply_weapon_visual()
		Settings.play("reload", -10.0, 1.4)
	if controls.take("reload"):
		_start_reload()
	if controls.take("grenade") and grenades > 0:
		grenades -= 1
		var fwd: Vector3 = -camera.global_transform.basis.z
		game.throw_grenade(camera.global_position + fwd * 0.6, fwd * 15.0 + Vector3.UP * 3.5)

	# ירי
	cooldown = maxf(0.0, cooldown - delta)
	if reloading:
		reload_left -= delta
		if reload_left <= 0.0:
			_finish_reload()
	var w: Dictionary = weapons[current]
	var want: bool = controls.is_firing()
	if Settings.auto_fire and not want and _crosshair_on_enemy():
		want = true
	var triggered: bool = want and (w["auto"] or not was_firing or Settings.auto_fire)
	was_firing = want
	if triggered and not reloading and cooldown <= 0.0:
		if mags[current] > 0:
			_shoot(w)
		elif reserves[current] > 0:
			_start_reload()
		else:
			Settings.play("empty", -6.0)
			cooldown = 0.35

	# אפקטים חזותיים
	recoil = move_toward(recoil, 0.0, delta * 9.0)
	gun.position = gun_rest + Vector3(0.0, 0.015 * recoil, 0.1 * recoil)
	gun.rotation.x = 0.12 * recoil
	if reloading:
		gun.rotation.x = -0.5
		gun.position.y = gun_rest.y - 0.1
	shake = move_toward(shake, 0.0, delta * 1.2)
	head.position = Vector3(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0), 0.0) * shake * 0.12 + Vector3(0, EYE_HEIGHT, 0)


func _start_reload() -> void:
	var w: Dictionary = weapons[current]
	if reloading or mags[current] >= w["mag"] or reserves[current] <= 0:
		return
	reloading = true
	reload_left = w["reload"]
	Settings.play("reload", -4.0, 1.0)


func _finish_reload() -> void:
	reloading = false
	var w: Dictionary = weapons[current]
	var need: int = int(w["mag"]) - int(mags[current])
	var take: int = mini(need, int(reserves[current]))
	mags[current] += take
	reserves[current] -= take


func _shoot(w: Dictionary) -> void:
	cooldown = w["rate"]
	mags[current] -= 1
	Settings.play(w["sound"], -3.0, randf_range(0.95, 1.05))
	recoil = 1.0
	pitch = clampf(pitch + float(w["kick"]), -1.45, 1.45)

	var space := get_world_3d().direct_space_state
	var cam_xf: Transform3D = camera.global_transform
	var origin: Vector3 = cam_xf.origin
	var base_dir: Vector3 = _aim_assist(-cam_xf.basis.z)
	var d_dims: Vector3 = w["dims"]
	var muzzle_pos: Vector3 = cam_xf * (gun_rest + Vector3(0.0, 0.02, -d_dims.z * 0.5))

	var hit_enemy: bool = false
	var killed_any: bool = false
	var head_any: bool = false
	var sp: float = w["spread"]
	for i in int(w["pellets"]):
		var d: Vector3 = (base_dir + cam_xf.basis.x * randf_range(-sp, sp) + cam_xf.basis.y * randf_range(-sp, sp)).normalized()
		var end_pt: Vector3 = origin + d * 120.0
		var q := PhysicsRayQueryParameters3D.create(origin, end_pt, 5)
		var res: Dictionary = space.intersect_ray(q)
		if not res.is_empty():
			end_pt = res["position"]
			var col = res["collider"]
			if col != null and col.is_in_group("enemies"):
				var dist: float = origin.distance_to(end_pt)
				var head_hit: bool = end_pt.y > col.global_position.y + col.head_y
				var dmg: float = w["damage"]
				if int(w["pellets"]) > 1:
					dmg *= clampf(1.25 - dist / 30.0, 0.3, 1.0)
				var killed: bool = col.take_damage(dmg, head_hit)
				hit_enemy = true
				killed_any = killed_any or killed
				head_any = head_any or head_hit
				game.spawn_impact(end_pt, Color(0.9, 0.1, 0.1))
			else:
				game.spawn_impact(end_pt, Color(0.95, 0.85, 0.5))
		if i < 3:
			game.spawn_tracer(muzzle_pos, end_pt, Color(1.0, 0.9, 0.5))
	if hit_enemy:
		hit_marker.emit(head_any, killed_any)
		Settings.play("hit", -8.0)
	if mags[current] <= 0 and reserves[current] > 0:
		_start_reload()


func _aim_assist(dir: Vector3) -> Vector3:
	if not Settings.aim_assist:
		return dir
	var best: Vector3 = dir
	var best_ang: float = 0.07
	var cam_pos: Vector3 = camera.global_position
	for e in get_tree().get_nodes_in_group("enemies"):
		var to: Vector3 = e.global_position + Vector3(0.0, 1.2, 0.0) - cam_pos
		var ang: float = dir.angle_to(to)
		if ang < best_ang:
			best_ang = ang
			best = dir.lerp(to.normalized(), 0.6).normalized()
	return best


func _crosshair_on_enemy() -> bool:
	var space := get_world_3d().direct_space_state
	var o: Vector3 = camera.global_position
	var q := PhysicsRayQueryParameters3D.create(o, o + (-camera.global_transform.basis.z) * 60.0, 5)
	var res: Dictionary = space.intersect_ray(q)
	if res.is_empty():
		return false
	return res["collider"].is_in_group("enemies")


func take_damage(amount: float) -> void:
	if not alive:
		return
	var absorbed: float = minf(armor, amount * 0.5)
	armor -= absorbed
	hp -= amount - absorbed
	damaged.emit(amount)
	Settings.play("hurt", -2.0, randf_range(0.95, 1.05))
	shake = maxf(shake, 0.35)
	if hp <= 0.0:
		hp = 0.0
		alive = false
		died.emit()


func pick_up(kind: String) -> bool:
	match kind:
		"health":
			if hp >= max_hp:
				return false
			hp = minf(max_hp, hp + 35.0)
		"armor":
			if armor >= max_armor:
				return false
			armor = minf(max_armor, armor + 50.0)
		"ammo":
			for i in weapons.size():
				var w: Dictionary = weapons[i]
				reserves[i] = mini(int(w["reserve"]), int(reserves[i]) + int(w["mag"]) * 2)
		"grenade":
			if grenades >= 6:
				return false
			grenades += 1
	return true
