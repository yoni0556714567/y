extends Control
## ממשק משחק: חיים, שריון, תחמושת, גל, ניקוד, כוונת, תפריט הפסקה ומסך סיום

signal resume_pressed
signal restart_pressed
signal menu_pressed

var hp: float = 100.0
var armor: float = 0.0
var weapon_name: String = ""
var ammo_text: String = ""
var grenades: int = 0
var wave: int = 0
var score: int = 0
var enemies: int = 0
var reloading: bool = false

var banner: String = ""
var banner_t: float = 0.0
var hit_t: float = 0.0
var hit_kill: bool = false
var damage_t: float = 0.0

var pause_root: Control
var over_root: Control
var over_label: Label


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	theme = Theme.new()
	theme.default_font_size = 28

	var p: Array = _make_panel("הפסקה")
	pause_root = p[0]
	_add_button(p[1], "המשך", func() -> void: resume_pressed.emit())
	_add_button(p[1], "התחל מחדש", func() -> void: restart_pressed.emit())
	_add_button(p[1], "תפריט ראשי", func() -> void: menu_pressed.emit())

	var o: Array = _make_panel("המשחק נגמר")
	over_root = o[0]
	over_label = Label.new()
	over_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	o[1].add_child(over_label)
	_add_button(o[1], "שחק שוב", func() -> void: restart_pressed.emit())
	_add_button(o[1], "תפריט ראשי", func() -> void: menu_pressed.emit())


func _make_panel(title_text: String) -> Array:
	var root := CenterContainer.new()
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.visible = false
	var pc := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0, 0, 0, 0.8)
	sb.set_corner_radius_all(16)
	sb.set_content_margin_all(30)
	pc.add_theme_stylebox_override("panel", sb)
	root.add_child(pc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	pc.add_child(vb)
	var t := Label.new()
	t.text = title_text
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.add_theme_font_size_override("font_size", 44)
	vb.add_child(t)
	return [root, vb]


func _add_button(parent: Control, text: String, cb: Callable) -> void:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(340, 66)
	b.pressed.connect(cb)
	parent.add_child(b)


func update_stats(p, w: int, sc: int, en: int) -> void:
	hp = p.hp
	armor = p.armor
	var wp: Dictionary = p.weapons[p.current]
	weapon_name = wp["name"]
	ammo_text = "%d / %d" % [p.mags[p.current], p.reserves[p.current]]
	grenades = p.grenades
	reloading = p.reloading
	wave = w
	score = sc
	enemies = en


func show_banner(text: String, secs: float = 2.5) -> void:
	banner = text
	banner_t = secs


func flash_damage() -> void:
	damage_t = 1.0


func show_hit(_head: bool, kill: bool) -> void:
	hit_t = 0.25
	hit_kill = kill


func show_pause(on: bool) -> void:
	pause_root.visible = on


func show_game_over(sc: int, w: int, high: int) -> void:
	over_label.text = "גל: %d\nניקוד: %d\nשיא: %d" % [w, sc, high]
	over_root.visible = true


func _process(delta: float) -> void:
	banner_t = maxf(0.0, banner_t - delta)
	hit_t = maxf(0.0, hit_t - delta)
	damage_t = maxf(0.0, damage_t - delta * 2.0)
	queue_redraw()


func _text(txt: String, pos: Vector2, width: float, fsize: int, col: Color, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT) -> void:
	var font: Font = ThemeDB.fallback_font
	draw_string_outline(font, pos, txt, align, width, fsize, 6, Color(0, 0, 0, col.a))
	draw_string(font, pos, txt, align, width, fsize, col)


func _draw() -> void:
	var s: Vector2 = size
	if damage_t > 0.0:
		draw_rect(Rect2(Vector2.ZERO, s), Color(0.8, 0.0, 0.0, 0.35 * damage_t))

	# חיים ושריון
	draw_rect(Rect2(20, 20, 300, 26), Color(0, 0, 0, 0.5))
	draw_rect(Rect2(20, 20, 300.0 * clampf(hp / 100.0, 0.0, 1.0), 26), Color(0.85, 0.2, 0.2))
	_text("%d" % int(ceil(hp)), Vector2(28, 42), 280, 22, Color.WHITE)
	draw_rect(Rect2(20, 52, 300, 14), Color(0, 0, 0, 0.5))
	draw_rect(Rect2(20, 52, 300.0 * clampf(armor / 100.0, 0.0, 1.0), 14), Color(0.3, 0.55, 1.0))

	# גל וניקוד
	_text("גל %d    ניקוד %d    אויבים %d" % [wave, score, enemies], Vector2(0, 44), s.x, 30, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)

	# תחמושת
	var ammo_line: String = "%s    %s" % [weapon_name, ammo_text]
	if reloading:
		ammo_line = "%s    טוען..." % weapon_name
	_text(ammo_line, Vector2(0, s.y - 56), s.x, 36, Color(1, 0.95, 0.7), HORIZONTAL_ALIGNMENT_CENTER)
	_text("רימונים: %d" % grenades, Vector2(0, s.y - 20), s.x, 26, Color(0.85, 0.9, 0.85), HORIZONTAL_ALIGNMENT_CENTER)

	# כוונת
	var c: Vector2 = s * 0.5
	var cc: Color = Color(1, 1, 1, 0.9)
	draw_line(c + Vector2(-14, 0), c + Vector2(-5, 0), cc, 2.0)
	draw_line(c + Vector2(5, 0), c + Vector2(14, 0), cc, 2.0)
	draw_line(c + Vector2(0, -14), c + Vector2(0, -5), cc, 2.0)
	draw_line(c + Vector2(0, 5), c + Vector2(0, 14), cc, 2.0)
	if hit_t > 0.0:
		var hc: Color = Color(1, 0.2, 0.2) if hit_kill else Color(1, 1, 1)
		draw_line(c + Vector2(-12, -12), c + Vector2(-6, -6), hc, 3.0)
		draw_line(c + Vector2(12, -12), c + Vector2(6, -6), hc, 3.0)
		draw_line(c + Vector2(-12, 12), c + Vector2(-6, 6), hc, 3.0)
		draw_line(c + Vector2(12, 12), c + Vector2(6, 6), hc, 3.0)

	# הודעה מרכזית
	if banner_t > 0.0:
		_text(banner, Vector2(0, 170), s.x, 60, Color(1, 0.9, 0.4, clampf(banner_t, 0.0, 1.0)), HORIZONTAL_ALIGNMENT_CENTER)
