extends Control
## תפריט ראשי והגדרות

var main_root: Control
var settings_root: Control


func _ready() -> void:
	theme = Theme.new()
	theme.default_font_size = 28
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

	var bg := ColorRect.new()
	bg.color = Color(0.07, 0.1, 0.08)
	add_child(bg)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_build_main()
	_build_settings()


func _center_root() -> CenterContainer:
	var root := CenterContainer.new()
	add_child(root)
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	return root


func _build_main() -> void:
	main_root = _center_root()
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 16)
	main_root.add_child(vb)

	var title := Label.new()
	title.text = "SOLDIER STRIKE"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 76)
	title.add_theme_color_override("font_color", Color(0.85, 0.9, 0.6))
	vb.add_child(title)

	var sub := Label.new()
	sub.text = "משחק ירי בגוף ראשון"
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(sub)

	var hs := Label.new()
	hs.text = "שיא: %d    גל מקסימלי: %d" % [Settings.high_score, Settings.best_wave]
	hs.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hs.add_theme_color_override("font_color", Color(1, 0.85, 0.4))
	vb.add_child(hs)

	_button(vb, "התחל משחק", _on_start)
	_button(vb, "הגדרות", _on_settings)
	if OS.get_name() != "Android" and OS.get_name() != "iOS":
		_button(vb, "יציאה", _on_quit)


func _build_settings() -> void:
	settings_root = _center_root()
	settings_root.visible = false
	var pc := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0, 0, 0, 0.7)
	sb.set_corner_radius_all(16)
	sb.set_content_margin_all(24)
	pc.add_theme_stylebox_override("panel", sb)
	settings_root.add_child(pc)

	var outer := VBoxContainer.new()
	outer.add_theme_constant_override("separation", 12)
	pc.add_child(outer)

	var t := Label.new()
	t.text = "הגדרות"
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.add_theme_font_size_override("font_size", 44)
	outer.add_child(t)

	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(820, 380)
	outer.add_child(sc)
	var rows := VBoxContainer.new()
	rows.add_theme_constant_override("separation", 14)
	rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(rows)

	_slider_row(rows, "רגישות מבט", "sensitivity", 0.3, 3.0, 0.05)
	_slider_row(rows, "שדה ראייה", "fov", 60.0, 100.0, 1.0)
	_slider_row(rows, "עוצמת קול", "volume", 0.0, 1.0, 0.05)

	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 20)
	rows.add_child(hb)
	var dl := Label.new()
	dl.text = "רמת קושי"
	dl.custom_minimum_size = Vector2(260, 0)
	hb.add_child(dl)
	var ob := OptionButton.new()
	ob.add_item("קל", 0)
	ob.add_item("רגיל", 1)
	ob.add_item("קשה", 2)
	ob.selected = Settings.difficulty
	ob.custom_minimum_size = Vector2(240, 52)
	ob.item_selected.connect(_on_difficulty)
	hb.add_child(ob)

	_toggle_row(rows, "סיוע כוונה", "aim_assist")
	_toggle_row(rows, "ירי אוטומטי כשהכוונת על אויב", "auto_fire")
	_toggle_row(rows, "היפוך ציר אנכי", "invert_y")
	_toggle_row(rows, "צללים (כבה אם המשחק איטי)", "shadows")

	_button(outer, "חזרה", _on_back)


func _button(parent: Control, text: String, cb: Callable) -> void:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(360, 68)
	b.pressed.connect(cb)
	parent.add_child(b)


func _slider_row(parent: Control, text: String, prop: String, mn: float, mx: float, step: float) -> void:
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 20)
	parent.add_child(hb)
	var l := Label.new()
	l.text = text
	l.custom_minimum_size = Vector2(260, 0)
	hb.add_child(l)
	var sl := HSlider.new()
	sl.min_value = mn
	sl.max_value = mx
	sl.step = step
	sl.value = Settings.get(prop)
	sl.custom_minimum_size = Vector2(340, 44)
	sl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hb.add_child(sl)
	var vl := Label.new()
	vl.text = "%.2f" % sl.value
	vl.custom_minimum_size = Vector2(90, 0)
	hb.add_child(vl)
	sl.value_changed.connect(_on_slider.bind(prop, vl))


func _toggle_row(parent: Control, text: String, prop: String) -> void:
	var cb := CheckButton.new()
	cb.text = text
	cb.button_pressed = Settings.get(prop)
	cb.custom_minimum_size = Vector2(0, 52)
	cb.toggled.connect(_on_toggle.bind(prop))
	parent.add_child(cb)


func _on_slider(v: float, prop: String, vl: Label) -> void:
	Settings.set(prop, v)
	vl.text = "%.2f" % v


func _on_toggle(pressed: bool, prop: String) -> void:
	Settings.set(prop, pressed)


func _on_difficulty(index: int) -> void:
	Settings.difficulty = index


func _on_start() -> void:
	Settings.save_data()
	get_tree().change_scene_to_file("res://scenes/game.tscn")


func _on_settings() -> void:
	main_root.visible = false
	settings_root.visible = true


func _on_back() -> void:
	Settings.save_data()
	settings_root.visible = false
	main_root.visible = true


func _on_quit() -> void:
	get_tree().quit()
