#!/usr/bin/env bash
# סקריפט קימפול ל-APK (Linux / macOS)
# שימוש:  ./build_apk.sh /path/to/godot
set -e
cd "$(dirname "$0")"

GODOT="${GODOT:-${1:-godot}}"
export ANDROID_HOME="${ANDROID_HOME:-$HOME/Android/Sdk}"
[ "$(uname)" = "Darwin" ] && export ANDROID_HOME="${ANDROID_HOME_MAC:-${ANDROID_HOME:-$HOME/Library/Android/sdk}}"

command -v "$GODOT" >/dev/null 2>&1 || [ -x "$GODOT" ] || { echo "[שגיאה] לא נמצא Godot: $GODOT"; echo "הרץ: ./build_apk.sh /path/to/godot"; exit 1; }
[ -d "$ANDROID_HOME" ] || { echo "[שגיאה] לא נמצא Android SDK ב-$ANDROID_HOME (הגדר ANDROID_HOME)"; exit 1; }
command -v keytool >/dev/null 2>&1 || { echo "[שגיאה] לא נמצא keytool. התקן JDK 17."; exit 1; }

KS="$PWD/debug.keystore"
if [ ! -f "$KS" ]; then
  echo "יוצר מפתח דיבאג..."
  keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android -keystore "$KS" \
    -storepass android -dname "CN=Android Debug,O=Android,C=US" -validity 9999 -deststoretype pkcs12
fi

export GODOT_ANDROID_KEYSTORE_DEBUG_PATH="$KS"
export GODOT_ANDROID_KEYSTORE_DEBUG_USER="androiddebugkey"
export GODOT_ANDROID_KEYSTORE_DEBUG_PASSWORD="android"

mkdir -p build
echo "מייבא משאבים..."
"$GODOT" --headless --path . --import || true
echo "מייצא APK..."
"$GODOT" --headless --path . --export-debug "Android" "$PWD/build/soldier_strike.apk"

echo
echo "הצלחה! הקובץ: $PWD/build/soldier_strike.apk"
