# Soldier Strike – משחק חייל בגוף ראשון (Godot 4.3)

משחק ירי תלת-ממדי בגוף ראשון לאנדרואיד. גלים של אויבים בזירה סגורה, 4 נשקים, רימונים, פריטי איסוף, שיאים נשמרים, תפריט הגדרות ובקרת מגע.

## מה יש במשחק
- **4 נשקים:** אקדח, רובה סער (אוטומטי), שוטגן, צלף. לכל נשק טעינה, רתע ותחמושת משלו.
- **רימונים:** נזק באזור, פוגעים גם בך אם אתה קרוב.
- **3 סוגי אויבים:** חייל (יורה), רץ (תוקף מקרוב), כבד (שריון ואש מהירה). פגיעה בראש גורמת לנזק כפול.
- **פריטים שנושרים:** חיים, שריון, תחמושת, רימונים.
- **גלים:** כל גל חזק יותר. בסוף כל גל מקבלים תגמול.
- **הגדרות:** רגישות מבט, שדה ראייה, עוצמת קול, רמת קושי, סיוע כוונה, ירי אוטומטי, היפוך ציר, צללים (כיבוי עוזר בטלפונים חלשים).
- **שיא וגל מקסימלי** נשמרים אוטומטית.

## בקרת מגע
- **צד שמאל:** ג'ויסטיק – נוגעים בכל מקום בחצי השמאלי והוא מופיע שם.
- **צד ימין (מסך פנוי):** החלקה להסתכלות.
- **כפתורים:** אש (אפשר להחליק עליו כדי לכוון תוך כדי ירי), קפוץ, טען, רימון, החלפת נשק, השהיה (למעלה בימין).
- כפתור "חזרה" של אנדרואיד משהה את המשחק.

## בדיקה במחשב
רצים ישר מהעורך (F5). מקשים: WASD תנועה, עכבר מבט, לחצן שמאלי ירי, רווח קפיצה, R טעינה, G רימון, Q החלפת נשק, ESC השהיה.

## קימפול ל-APK (פעם ראשונה)
1. הורד **Godot 4.3 Standard** (לא גרסת .NET) מ-godotengine.org.
2. התקן **JDK 17** ו-**Android SDK** (הדרך הקלה: להתקין Android Studio, ואז SDK Manager → להתקין Platform-Tools, Build-Tools 34.0.0, Platform android-34 ו-Command-line Tools).
3. ב-Godot: `Editor → Manage Export Templates → Download and Install`.
4. צור מפתח דיבאג (פעם אחת, בטרמינל):
   ```
   keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android -keystore debug.keystore -storepass android -dname "CN=Android Debug,O=Android,C=US" -validity 9999 -deststoretype pkcs12
   ```
5. ב-Godot: `Editor → Editor Settings → Export → Android` והגדר: נתיב Android SDK, נתיב JDK (Java SDK Path), ונתיב ל-debug.keystore (משתמש `androiddebugkey`, סיסמה `android`).
6. פתח את התיקייה `soldier_strike` כפרויקט ב-Godot (בפתיחה הראשונה הוא מייבא את הקבצים והצלילים).
7. `Project → Export → Add… → Android`. ב-Package Unique Name כתוב למשל `com.yoni.soldierstrike`.
8. לחץ **Export Project**, תן שם `soldier_strike.apk` והסר את הסימון Export With Debug אם אתה רוצה גרסת Release (לא חובה).
9. העבר את ה-APK לטלפון ואשר התקנה ממקורות לא ידועים.

## טיפים
- אם הטלפון חלש: כבה צללים בהגדרות והורד שדה ראייה.
- שינוי נשקים/נזק: בראש `scripts/player.gd` ברשימת `weapons`.
- שינוי אויבים: בראש `scripts/enemy.gd` (בבלוק `match kind`).
- גודל הזירה ומספר המכשולים: `scripts/game.gd`.

## הערה חשובה
הקוד נכתב בלי אפשרות להריץ אותו ב-Godot בסביבה שבה נוצר, ולכן ייתכנו שגיאות קטנות בהרצה הראשונה. אם יש שגיאה, העתק את הודעת השגיאה מחלונית Output/Debugger ושלח לי, ואתקן.

## קימפול אוטומטי עם סקריפט
אחרי שהתקנת Godot 4.3, Export Templates (`Editor → Manage Export Templates`), JDK 17 ו-Android SDK:
- **Windows:** `build_apk.bat` (אפשר ללחוץ פעמיים; אם לא נמצא Godot הוא יבקש שתגרור אליו את הקובץ. החלון נשאר פתוח, ויומן נשמר ב-`build_log.txt`)
- **Linux/Mac:** `./build_apk.sh /path/to/godot`

הסקריפט יוצר מפתח דיבאג בעצמו, מייבא את הפרויקט ומייצא את `build/soldier_strike.apk`. נתיב ה-SDK נלקח ממשתנה הסביבה `ANDROID_HOME` ו-Java מ-`JAVA_HOME`/`PATH`. אם Godot מתלונן שחסר נתיב SDK או JDK, הגדר אותם פעם אחת ב-`Editor Settings → Export → Android` ונסה שוב.
