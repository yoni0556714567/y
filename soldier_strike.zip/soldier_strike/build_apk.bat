@echo off
setlocal
cd /d "%~dp0"
set "LOG=%~dp0build_log.txt"
echo Build started > "%LOG%"

rem ===== Settings: edit if needed =====
if "%GODOT%"=="" set "GODOT=%~1"
if "%ANDROID_HOME%"=="" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
rem ====================================

:ask_godot
if exist "%GODOT%" goto have_godot
echo.
echo Godot was not found.
echo Drag the Godot console exe file into this window and press Enter.
echo Example name: Godot_v4.3-stable_win64_console.exe
set /p GODOT=Path:
set GODOT=%GODOT:"=%
goto ask_godot

:have_godot
echo Godot: %GODOT%

if exist "%ANDROID_HOME%" goto have_sdk
echo.
echo Android SDK not found at: %ANDROID_HOME%
echo Set the ANDROID_HOME environment variable to your SDK folder, then run again.
goto fail

:have_sdk
echo Android SDK: %ANDROID_HOME%

where keytool >nul 2>nul
if not errorlevel 1 goto have_java
if "%JAVA_HOME%"=="" goto no_java
set "PATH=%JAVA_HOME%\bin;%PATH%"
where keytool >nul 2>nul
if not errorlevel 1 goto have_java
:no_java
echo.
echo Java keytool not found. Install JDK 17 and set JAVA_HOME, then run again.
goto fail

:have_java
set "KS=%~dp0debug.keystore"
if exist "%KS%" goto have_ks
echo Creating debug keystore...
keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android -keystore "%KS%" -storepass android -dname "CN=Android Debug,O=Android,C=US" -validity 9999 -deststoretype pkcs12
if errorlevel 1 goto fail

:have_ks
set "GODOT_ANDROID_KEYSTORE_DEBUG_PATH=%KS%"
set "GODOT_ANDROID_KEYSTORE_DEBUG_USER=androiddebugkey"
set "GODOT_ANDROID_KEYSTORE_DEBUG_PASSWORD=android"

if not exist build mkdir build

echo.
echo Step 1/2: importing project, this can take a minute...
"%GODOT%" --headless --path "%~dp0." --import >> "%LOG%" 2>&1

echo Step 2/2: exporting APK...
"%GODOT%" --headless --path "%~dp0." --export-debug "Android" "%~dp0build\soldier_strike.apk" >> "%LOG%" 2>&1
set "RC=%ERRORLEVEL%"

if not exist "%~dp0build\soldier_strike.apk" goto export_failed
echo.
echo SUCCESS. APK file:
echo %~dp0build\soldier_strike.apk
goto done

:export_failed
echo.
echo Export FAILED, exit code %RC%.
echo Last lines of the log:
echo ----------------------------------------
powershell -NoProfile -Command "Get-Content -Tail 25 '%LOG%'"
echo ----------------------------------------
echo Full log: %LOG%
echo Common causes: Export Templates not installed, or SDK/JDK path missing in Godot Editor Settings - Export - Android.
goto fail

:fail
echo.
echo Build did not finish.
pause
exit /b 1

:done
echo.
pause
endlocal
